# ☕ COFFEE-IN — Specialty Coffee Experience

> A beautifully crafted, fully responsive coffee shop web application.

![COFFEE-IN Preview](https://img.shields.io/badge/COFFEE--IN-Live%20App-brown?style=for-the-badge&logo=coffeescript)
![HTML](https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS3-1572B6?style=flat&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)

---

## 🌟 Features

- **Animated Hero Section** — CSS-art coffee cup with steam & orbiting beans
- **Interactive Menu** — Filter by category (Hot, Cold, Specials, Food) with cart
- **Quick Order Modal** — Add items to cart and place orders
- **Testimonials Carousel** — Auto-sliding customer reviews
- **Photo Gallery** — Responsive masonry-style layout
- **Contact Form** — With validation and success feedback
- **Newsletter Signup** — Email subscription in footer
- **Page Loader** — Branded animated loading screen
- **Responsive Design** — Mobile-first, works on all screen sizes
- **Smooth Scroll Animations** — Intersection Observer fade-in effects
- **Sticky Navbar** — With scroll behavior and mobile hamburger menu

---

## 🗂️ Project Structure

```
COFFEE-IN/
├── index.html          # Main HTML file
├── css/
│   └── style.css       # All styles (CSS variables, animations, responsive)
├── js/
│   └── app.js          # All interactivity (menu, cart, modal, carousel)
├── README.md           # This file
└── .gitignore
```

---

## 🚀 Getting Started

### Option 1: Open directly
Just double-click `index.html` in your browser — no build step needed!

### Option 2: Use Live Server (VS Code)
1. Install the **Live Server** extension in VS Code
2. Right-click `index.html` → **Open with Live Server**

### Option 3: GitHub Pages (free hosting)
1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to `main` branch, root `/`
4. Your site will be live at `https://yourusername.github.io/COFFEE-IN/`

---

## 📦 Uploading to GitHub

```bash
# Initialize Git
git init

# Add all files
git add .

# First commit
git commit -m "🚀 Initial commit: COFFEE-IN web app"

# Add your GitHub remote
git remote add origin https://github.com/YOUR_USERNAME/COFFEE-IN.git

# Push to GitHub
git branch -M main
git push -u origin main
```

---

## 🎨 Design System

| Token | Value | Usage |
|-------|-------|-------|
| `--espresso` | `#1a0a00` | Primary dark |
| `--caramel` | `#c67c2b` | Accent / CTA |
| `--gold` | `#e4a132` | Highlights |
| `--cream` | `#f5e6c8` | Backgrounds |
| `--foam` | `#fffaf3` | Cards |

**Fonts:** Playfair Display (headings) + DM Sans (body)

---

## 📱 Responsive Breakpoints

| Breakpoint | Layout |
|------------|--------|
| `> 1024px` | Full desktop — 2-col hero, 4-col footer |
| `768–1024px` | Tablet — adjusted grids |
| `< 768px` | Mobile — stacked, hamburger menu |
| `< 480px` | Small mobile — single column |

---

## 🛠️ Tech Stack

- **HTML5** — Semantic markup
- **CSS3** — Custom properties, Grid, Flexbox, Animations, `@keyframes`
- **Vanilla JavaScript** — No frameworks, no dependencies
- **Google Fonts** — Playfair Display + DM Sans

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

Made with ☕ and ❤️ by **COFFEE-IN**
