/* ============================
   COFFEE-IN — JAVASCRIPT
   ============================ */

// ===== DATA =====
const menuItems = [
  { id: 1, name: "Classic Espresso", desc: "Pure, concentrated perfection. Double shot, dark roast.", price: 120, emoji: "☕", category: "hot", badge: "Popular" },
  { id: 2, name: "Cappuccino", desc: "Velvety microfoam, rich espresso, morning ritual.", price: 180, emoji: "☕", category: "hot", badge: null },
  { id: 3, name: "Flat White", desc: "Australian-style, smooth milk, bold espresso core.", price: 190, emoji: "☕", category: "hot", badge: "New" },
  { id: 4, name: "Pour Over", desc: "Hand-crafted, single origin, bright and floral notes.", price: 210, emoji: "🫗", category: "hot", badge: "Specialty" },
  { id: 5, name: "Cold Brew", desc: "18-hour steep. Silky smooth, zero bitterness.", price: 220, emoji: "🧊", category: "cold", badge: "Popular" },
  { id: 6, name: "Iced Latte", desc: "Chilled espresso over ice with creamy oat milk.", price: 200, emoji: "🥤", category: "cold", badge: null },
  { id: 7, name: "Nitro Cold Brew", desc: "Cold brew infused with nitrogen. Creamy, bubbly bliss.", price: 260, emoji: "🫧", category: "cold", badge: "Special" },
  { id: 8, name: "Affogato", desc: "Espresso poured over vanilla gelato. Italian classic.", price: 280, emoji: "🍦", category: "special", badge: "Chef's Pick" },
  { id: 9, name: "Honey Oat Latte", desc: "Oat milk, local honey, cinnamon, single-origin espresso.", price: 240, emoji: "🍯", category: "special", badge: "Seasonal" },
  { id: 10, name: "Avocado Toast", desc: "Smashed avo, cherry tomatoes, EVOO on sourdough.", price: 220, emoji: "🥑", category: "food", badge: null },
  { id: 11, name: "Almond Croissant", desc: "Flaky, buttery, filled with frangipane. Baked daily.", price: 160, emoji: "🥐", category: "food", badge: "Bakery" },
  { id: 12, name: "Banana Bread", desc: "Whole grain, walnuts, house-made, served warm.", price: 140, emoji: "🍞", category: "food", badge: null },
];

const testimonials = [
  { name: "Priya Sharma", title: "Coffee Enthusiast", text: "COFFEE-IN changed my mornings forever. The pour-over is unlike anything I've tasted in Hyderabad.", stars: 5, initials: "PS" },
  { name: "Arjun Reddy", title: "WFH Warrior", text: "The nitro cold brew is absolutely phenomenal. I come here every single day and the staff knows my order!", stars: 5, initials: "AR" },
  { name: "Meera Nair", title: "Food Blogger", text: "Not just amazing coffee — the ambiance, the service, the food. It's a full experience. Can't recommend enough.", stars: 5, initials: "MN" },
  { name: "Rohan Verma", title: "Startup Founder", text: "My office is basically COFFEE-IN now. The cold brew keeps me going and the WiFi is fast. Perfect setup.", stars: 5, initials: "RV" },
  { name: "Ananya Singh", title: "Food Critic", text: "The affogato is a work of art. I've had it in Italy, but COFFEE-IN's version holds its own. Bravo!", stars: 5, initials: "AS" },
];

// ===== STATE =====
let cart = {};
let currentFilter = "all";
let currentSlide = 0;
let totalSlides = 0;
let autoSlideTimer;

// ===== INIT =====
document.addEventListener("DOMContentLoaded", () => {
  initLoader();
  initNavbar();
  initHamburger();
  renderMenuGrid();
  initMenuFilters();
  renderTestimonials();
  initScrollAnimations();
  initBackToTop();
  initTestimonialAutoSlide();
});

// ===== LOADER =====
function initLoader() {
  const loader = document.getElementById("loader");
  setTimeout(() => {
    loader.classList.add("hidden");
    document.body.style.overflow = "auto";
  }, 2200);
  document.body.style.overflow = "hidden";
}

// ===== NAVBAR =====
function initNavbar() {
  const navbar = document.getElementById("navbar");
  window.addEventListener("scroll", () => {
    navbar.classList.toggle("scrolled", window.scrollY > 60);
  });
}

// ===== HAMBURGER =====
function initHamburger() {
  const hamburger = document.getElementById("hamburger");
  const mobileMenu = document.getElementById("mobileMenu");
  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("active");
    mobileMenu.classList.toggle("open");
  });
  document.addEventListener("click", (e) => {
    if (!hamburger.contains(e.target) && !mobileMenu.contains(e.target)) {
      hamburger.classList.remove("active");
      mobileMenu.classList.remove("open");
    }
  });
}

function closeMobileMenu() {
  document.getElementById("hamburger").classList.remove("active");
  document.getElementById("mobileMenu").classList.remove("open");
}

// ===== MENU =====
function renderMenuGrid(filter = "all") {
  const grid = document.getElementById("menuGrid");
  grid.innerHTML = menuItems.map(item => `
    <div class="menu-card fade-up ${filter !== 'all' && item.category !== filter ? 'hidden' : ''}"
         data-category="${item.category}" onclick="addToCart(${item.id})">
      <div class="card-img" style="background:${getCategoryGradient(item.category)}">
        <span>${item.emoji}</span>
        ${item.badge ? `<span class="card-badge">${item.badge}</span>` : ''}
      </div>
      <div class="card-body">
        <div class="card-name">${item.name}</div>
        <div class="card-desc">${item.desc}</div>
        <div class="card-footer">
          <span class="card-price">₹${item.price}</span>
          <button class="card-add-btn" onclick="event.stopPropagation(); addToCartWithFeedback(${item.id}, this)">+</button>
        </div>
      </div>
    </div>
  `).join('');
  triggerFadeUps();
}

function getCategoryGradient(category) {
  const gradients = {
    hot: 'linear-gradient(135deg, #3d1a06, #7a3510)',
    cold: 'linear-gradient(135deg, #1a3a5c, #2d6a9f)',
    special: 'linear-gradient(135deg, #3a1a5c, #6a3a9f)',
    food: 'linear-gradient(135deg, #2c4a1e, #5a8a3a)',
  };
  return gradients[category] || gradients.hot;
}

function initMenuFilters() {
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      currentFilter = this.dataset.filter;
      filterMenu(currentFilter);
    });
  });
}

function filterMenu(filter) {
  document.querySelectorAll('.menu-card').forEach(card => {
    if (filter === 'all' || card.dataset.category === filter) {
      card.classList.remove('hidden');
      card.classList.add('fade-up');
      setTimeout(() => card.classList.add('visible'), 50);
    } else {
      card.classList.add('hidden');
    }
  });
}

// ===== CART =====
function addToCart(id) {
  const item = menuItems.find(i => i.id === id);
  if (!item) return;
  cart[id] = (cart[id] || 0) + 1;
}

function addToCartWithFeedback(id, btn) {
  addToCart(id);
  const original = btn.textContent;
  btn.textContent = '✓';
  btn.style.background = 'var(--caramel)';
  btn.style.color = 'white';
  setTimeout(() => {
    btn.textContent = original;
    btn.style.background = '';
    btn.style.color = '';
  }, 800);
  showToast(`Added to cart!`);
}

function showToast(msg) {
  const toast = document.createElement('div');
  toast.textContent = msg;
  toast.style.cssText = `
    position: fixed; bottom: 5rem; left: 50%; transform: translateX(-50%);
    background: var(--espresso); color: var(--gold); padding: 0.7rem 1.5rem;
    border-radius: 50px; font-size: 0.85rem; z-index: 3000;
    animation: fadeIn 0.3s ease; box-shadow: 0 4px 20px rgba(0,0,0,0.2);
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2000);
}

// ===== ORDER MODAL =====
function openOrderModal() {
  const modal = document.getElementById('orderModal');
  const orderItems = document.getElementById('orderItems');
  const cartSummary = document.getElementById('cartSummary');
  const orderSuccess = document.getElementById('orderSuccess');

  orderItems.innerHTML = menuItems.slice(0, 6).map(item => `
    <div class="order-item">
      <div class="order-item-info">
        <span class="order-item-icon">${item.emoji}</span>
        <div>
          <div class="order-item-name">${item.name}</div>
          <div class="order-item-price">₹${item.price}</div>
        </div>
      </div>
      <button class="order-add-btn" onclick="addToOrderCart(${item.id})">+</button>
    </div>
  `).join('');

  cartSummary.style.display = 'none';
  orderSuccess.style.display = 'none';
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeOrderModal() {
  document.getElementById('orderModal').classList.remove('open');
  document.body.style.overflow = 'auto';
  cart = {};
}

function addToOrderCart(id) {
  addToCart(id);
  updateCartSummary();
}

function updateCartSummary() {
  const cartSummary = document.getElementById('cartSummary');
  const cartItemsEl = document.getElementById('cartItems');
  const cartTotal = document.getElementById('cartTotal');

  const keys = Object.keys(cart);
  if (keys.length === 0) { cartSummary.style.display = 'none'; return; }

  cartSummary.style.display = 'block';
  let total = 0;
  cartItemsEl.innerHTML = keys.map(id => {
    const item = menuItems.find(i => i.id == id);
    const subtotal = item.price * cart[id];
    total += subtotal;
    return `<div class="cart-item"><span>${item.name} × ${cart[id]}</span><span>₹${subtotal}</span></div>`;
  }).join('');
  cartTotal.textContent = `₹${total}`;
}

function placeOrder() {
  document.getElementById('cartSummary').style.display = 'none';
  document.getElementById('orderItems').style.display = 'none';
  document.getElementById('orderSuccess').style.display = 'block';
  cart = {};
}

// Close modal on overlay click
document.getElementById('orderModal').addEventListener('click', function(e) {
  if (e.target === this) closeOrderModal();
});

// ===== TESTIMONIALS =====
function renderTestimonials() {
  const track = document.getElementById('testimonialTrack');
  const dots = document.getElementById('carouselDots');
  const isMobile = window.innerWidth <= 768;
  const visibleSlides = isMobile ? 1 : window.innerWidth <= 1024 ? 2 : 3;

  track.innerHTML = testimonials.map(t => `
    <div class="testimonial-card fade-up">
      <div class="testi-stars">${'★'.repeat(t.stars)}</div>
      <p class="testi-text">"${t.text}"</p>
      <div class="testi-author">
        <div class="testi-avatar">${t.initials}</div>
        <div>
          <div class="testi-name">${t.name}</div>
          <div class="testi-title">${t.title}</div>
        </div>
      </div>
    </div>
  `).join('');

  totalSlides = Math.ceil(testimonials.length / visibleSlides);
  dots.innerHTML = Array.from({ length: totalSlides }, (_, i) =>
    `<button class="dot ${i === 0 ? 'active' : ''}" onclick="goToSlide(${i})"></button>`
  ).join('');
}

function goToSlide(index) {
  const track = document.getElementById('testimonialTrack');
  const dots = document.querySelectorAll('.dot');
  const isMobile = window.innerWidth <= 768;
  const cardWidth = isMobile ? 80 : window.innerWidth <= 1024 ? 50 : 33.333;
  const gapPx = 24;
  const offset = index * (cardWidth + (gapPx / track.offsetWidth * 100));

  track.style.transform = `translateX(-${index * (cardWidth + 2)}%)`;
  currentSlide = index;
  dots.forEach((d, i) => d.classList.toggle('active', i === index));
}

function initTestimonialAutoSlide() {
  autoSlideTimer = setInterval(() => {
    currentSlide = (currentSlide + 1) % totalSlides;
    goToSlide(currentSlide);
  }, 4000);
}

// ===== CONTACT FORM =====
function submitContact() {
  const name = document.getElementById('cName').value.trim();
  const email = document.getElementById('cEmail').value.trim();
  const msg = document.getElementById('cMsg').value.trim();
  const success = document.getElementById('formSuccess');

  if (!name || !email || !msg) {
    showToast('Please fill in all fields!');
    return;
  }

  const btn = document.querySelector('.contact-form .btn-primary');
  btn.textContent = 'Sending...';
  btn.disabled = true;

  setTimeout(() => {
    success.style.display = 'block';
    btn.textContent = 'Send Message';
    btn.disabled = false;
    document.getElementById('cName').value = '';
    document.getElementById('cEmail').value = '';
    document.getElementById('cMsg').value = '';
    setTimeout(() => { success.style.display = 'none'; }, 5000);
  }, 1500);
}

// ===== NEWSLETTER =====
function subscribeNewsletter() {
  const email = document.getElementById('nlEmail').value.trim();
  const success = document.getElementById('nlSuccess');
  if (!email || !email.includes('@')) {
    showToast('Enter a valid email!');
    return;
  }
  success.textContent = '☕ You\'re subscribed! Welcome to the COFFEE-IN family.';
  document.getElementById('nlEmail').value = '';
}

// ===== SCROLL ANIMATIONS =====
function initScrollAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

  document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
}

function triggerFadeUps() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('visible');
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.fade-up:not(.visible)').forEach(el => observer.observe(el));
}

// ===== BACK TO TOP =====
function initBackToTop() {
  const btn = document.getElementById('backToTop');
  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 500);
  });
}

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function scrollToMenu() {
  document.getElementById('menu').scrollIntoView({ behavior: 'smooth' });
}

function scrollToContact() {
  document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
}

// ===== WINDOW RESIZE =====
window.addEventListener('resize', () => {
  clearInterval(autoSlideTimer);
  renderTestimonials();
  initTestimonialAutoSlide();
});
